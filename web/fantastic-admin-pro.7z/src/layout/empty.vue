<template>
    <RouterView />
</template>

<script>
export default {
    name: 'EmptyLayout',
    props: {},
    data() {
        return {}
    },
    created() {},
    mounted() {},
    methods: {}
}
</script>
