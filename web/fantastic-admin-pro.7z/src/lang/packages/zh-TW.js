export default {
    app: {
        profile: '我的資料',
        login: '登 錄',
        logout: '退出登錄',
        account: '賬號',
        password: '密碼',
        captcha: '驗證碼',
        sendCaptcha: '發送驗證碼',
        newPassword: '新密碼',
        goLogin: '去登錄',
        check: '確 認'
    },
    route: {
        login: '登錄',
        dashboard: '歡迎頁',
        personal: {
            setting: '我的設置',
            editpassword: '修改密碼'
        },
        i18n: '國際化'
    }
}
