export default {
    app: {
        profile: '个人设置',
        login: '登 录',
        logout: '退出登录',
        account: '用户名',
        password: '密码',
        captcha: '验证码',
        sendCaptcha: '发送验证码',
        newPassword: '新密码',
        goLogin: '去登录',
        check: '确 认'
    },
    route: {
        login: '登录',
        dashboard: '控制台',
        personal: {
            setting: '个人设置',
            editpassword: '修改密码'
        },
        i18n: '国际化'
    }
}
