export default {
    app: {
        profile: 'Profile',
        login: 'Login',
        logout: 'Logout',
        account: 'account',
        password: 'password',
        captcha: 'captcha',
        sendCaptcha: 'send captcha',
        newPassword: 'new password',
        goLogin: 'go login',
        check: 'Submit'
    },
    route: {
        login: 'Login',
        dashboard: 'Dashboard',
        personal: {
            setting: 'Personal Setting',
            editpassword: 'Edit Password'
        },
        i18n: 'I18N'
    }
}
