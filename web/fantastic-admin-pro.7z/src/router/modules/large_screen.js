import Layout from '@/layout'

export default {
    path: '/largeScreen',
    component: Layout,
    redirect: '/largeScreen/list',
    name: 'largeScreen',
    meta: {
        title: '可视化大屏',
        icon: 'slide-screen'
    },
    children: [
        {
            path: '',
            component: () => import(/* webpackChunkName: 'largeScreen' */ '@/views/large_screen/list'),
            meta: {
                title: '可视化大屏',
                sidebar: false,
                breadcrumb: false
            }
        }
        // {
        //     path: 'largeScreenAdd',
        //     name: 'largeScreenAdd',
        //     component: () => import(/* webpackChunkName: 'systemManage' */ '@/views/large_screen/form'),
        //     meta: {
        //         title: '新增页面',
        //         sidebar: false,
        //         activeMenu: '/largeScreen'
        //     }
        // },
        // {
        //     path: 'largeScreenEdit/:id',
        //     name: 'largeScreenEdit',
        //     component: () => import(/* webpackChunkName: 'systemManage' */ '@/views/large_screen/form'),
        //     meta: {
        //         title: '编辑页面',
        //         sidebar: false,
        //         activeMenu: '/largeScreen'
        //     }
        // }
    ]
}