<template>
    <div>
        <page-header title="欢迎使用 Fantastic-admin（专业版）">
            <template #content>
                <div>
                    <div style="margin-bottom: 5px;">这是一款<b style="text-emphasis-style: '❤';">开箱即用</b>的中后台框架，同时它也经历过数十个真实项目的技术沉淀，确保框架在开发中可落地、可使用、可维护</div>
                    <div>注：在作者就职的公司，本框架已在电商、直播、OA、ERP等多个不同领域的中后台系统中应用并稳定运行</div>
                </div>
            </template>
        </page-header>
    </div>
</template>

<script>
export default {
    data() {
        return {}
    }
}
</script>
