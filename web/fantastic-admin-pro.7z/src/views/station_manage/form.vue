<template>
    <div>
        <!-- <page-main> -->
        <el-row>
            <!-- :lg="12" -->
            <el-col :md="24">
                <el-form ref="form" :inline="true" :rules="ruleForm" :model="form" label-width="120px" class="formBox">
                    <el-form-item label="系统名称" prop="web_sysname">
                        <el-input v-model="form.web_sysname" />
                    </el-form-item>
                    <el-form-item label="防护域名" prop="web_name">
                        <el-input v-model="form.web_name" />
                    </el-form-item>
                    <el-form-item label="源端口" prop="web_port">
                        <el-input v-model="form.web_port" />
                    </el-form-item>
                    <el-form-item label="源站地址" prop="source_ip">
                        <el-input v-model="form.source_ip" />
                    </el-form-item>
                    <el-form-item label="源端口" prop="web_port">
                        <el-input v-model="form.web_port" />
                    </el-form-item>
                    <el-form-item label="目的端口" prop="dst_port">
                        <el-input v-model="form.dst_port" />
                    </el-form-item>
                    <div>
                        <el-form-item label="是否开启https" prop="is_https">
                            <div style="width: 190px;">
                                <el-switch v-model="form.is_https" />
                            </div>
                        </el-form-item>
                        <el-form-item label="所属单位" prop="group_id">
                            <el-select v-model="form.group_id" placeholder="请选择所属单位">
                                <el-option label="郑州办事处" value="1" />
                                <el-option label="二里岗办事处" value="2" />
                                <el-option label="其他办事处" value="3" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="模式" prop="protect_status">
                            <el-radio-group v-model="form.protect_status">
                                <el-radio-button label="1">防护模式</el-radio-button>
                                <el-radio-button label="0">转发模式</el-radio-button>
                            </el-radio-group>
                        </el-form-item>
                    </div>
                    <div>
                        <el-form-item label="证书文件" prop="proxy_catefile">
                            <el-upload ref="upload"
                                       class="upload-demo"
                                       action="#" 
                                       :limit="1"
                                       :file-list="form.proxy_catefile"
                                       :on-preview="handlePreview"
                                       :on-remove="handleRemove"
                                       :auto-upload="false"
                                       :before-upload="beforeUpload"
                                       :on-change="changeUpload"
                            >
                                <el-button slot="trigger" size="small" type="primary">上传文件</el-button>
                            </el-upload>
                        </el-form-item>
                    </div>
                    <div>
                        <el-form-item label="密钥文件" prop="proxy_catekeyfile">
                            <el-upload ref="upload"
                                       class="upload-demo"
                                       action="#" 
                                       :limit="1"
                                       :file-list="form.proxy_catekeyfile"
                                       :on-preview="handlePreview"
                                       :on-remove="handleRemove"
                                       :auto-upload="false"
                                       :before-upload="beforeUpload"
                                       :on-change="changeUpload"
                            >
                                <el-button slot="trigger" size="small" type="primary">上传文件</el-button>
                            </el-upload>
                        </el-form-item>
                    </div>
                    <el-form-item label="证书链文件" prop="proxy_catechainfile">
                        <el-upload ref="upload"
                                   class="upload-demo"
                                   action="#" 
                                   :limit="1"
                                   :file-list="form.proxy_catechainfile"
                                   :on-preview="handlePreview"
                                   :on-remove="handleRemove"
                                   :auto-upload="false"
                                   :before-upload="beforeUpload"
                                   :on-change="changeUpload"
                        >
                            <el-button slot="trigger" size="small" type="primary">上传文件</el-button>
                        </el-upload>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <!-- </page-main> -->
        <!-- <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar> -->
        <div class="btn-box">
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </div>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    props: {
        dataInfo: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            id: '',
            form: {
                web_sysname: '',
                web_name: '',
                web_port: '',
                source_ip: '',
                dst_port: '',
                is_https: true,
                proxy_catefile: '',
                proxy_catekeyfile: '',
                proxy_catechainfile: '',
                protect_status: 1,
                group_id: '1'
            },
            ruleForm: {
                web_name: [
                    { required: true, message: '请输入防护域名', trigger: 'change' }
                ],
                web_port: [
                    { required: true, message: '请输入关键字', trigger: 'change' }
                ],
                source_ip: [
                    { required: true, message: '请输入源站地址', trigger: 'blur' }
                ],
                dst_port: [
                    { required: true, message: '请输入目的端口', trigger: 'blur' }
                ],
                is_https: [
                    { required: true, message: '请选择是否开启https', trigger: 'change' }
                ],
                protect_status: [
                    { required: true, message: '请选择模式', trigger: 'change' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        // if (this.$route.name == 'stationManageEdit') {
        //     this.id = this.$route.params.id
        //     this.initData()
        // }
        if (this.dataInfo) {
            this.id = this.dataInfo.id
            this.initData()
        }
        console.log(this.dataInfo, 'dataInfo')
    },
    methods: {
        initData() {
            this.$api.get('api/web/*')
                .then(res => {
                    this.form = res.data
                })
        },
        handlePreview() {},
        handleRemove() {},
        beforeUpload() {},
        changeUpload() {},
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    // console.log(this.form)
                    // this.$router.push('/systemManage/configModuleList')
                    this.$emit('formList')
                    this.$emit('openEditShow', false)
                  
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
            // this.openEditHadnle = false
            this.$emit('openEditShow', false)
        }
    }
}
</script>
