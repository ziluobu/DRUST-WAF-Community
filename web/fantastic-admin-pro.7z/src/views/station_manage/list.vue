<template>
    <div>
        <page-main>
            <el-button type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
            <search-bar>
                <el-form :model="search" size="small" label-width="100px">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="所属单位">
                                <el-input v-model="search.group_id" placeholder="请输入所属单位" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="防护域名">
                                <el-input v-model="search.web_name" placeholder="请输入防护域名" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="web_sysname" label="系统名称" />
                <el-table-column prop="web_name" label="防护域名" />
                <el-table-column prop="web_port" label="源端口" />
                <el-table-column prop="source_ip" label="源站地址" />
                <el-table-column prop="proxy_name" label="代理名称" />
                <el-table-column prop="dst_port" label="目的端口" />
                <el-table-column prop="is_https" label="是否开启https">
                    <template slot-scope="scope">
                        {{ scope.row.is_https==1?'是':'否' }}
                    </template>
                </el-table-column>
                <el-table-column prop="proxy_catefile" label="证书文件" />
                <el-table-column prop="proxy_catekeyfile" label="密钥文件" />
                <el-table-column prop="proxy_catechainfile" label="证书链文件" />
                <el-table-column prop="protect_status" label="模式">
                    <template slot-scope="scope">
                        {{ scope.row.protect_status == 1?'防护模式':'转发模式' }}
                    </template>
                </el-table-column>
                <el-table-column prop="group_id" label="所属单位" />
                <el-table-column prop="web_active" label="web_active" />
                <el-table-column prop="created_at" label="创建时间" width="160" />
                <el-table-column prop="updated_at" label="更新时间" width="160" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="primary" size="mini" plain @click="editHandle(scope.row)">编辑</el-button>
                        <el-dropdown @command="handleMoreOperating($event, scope.row)">
                            <el-button size="mini">
                                更多操作<i class="el-icon-arrow-down el-icon--right" />
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item command="detail">详情</el-dropdown-item>
                                <el-dropdown-item command="station">同步站点</el-dropdown-item>
                                <el-dropdown-item command="delete" divided>删除</el-dropdown-item>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>
                </el-table-column>
            </el-table>
            
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
            <el-dialog v-if="openEditHadnle" :key="timer" :title="titleText" :visible.sync="openEditHadnle" width="70%">
                <stationManageEdit :data-info="dataInfo" @openEditShow="openEditShow" @formList="initData" />
            </el-dialog>
            <el-dialog v-if="openDetailHadnle" :key="timer" :id-info="idInfo" title="详情" :visible.sync="openDetailHadnle" width="70%">
                <stationManageDetail />
            </el-dialog>
        </page-main>
    </div>
</template>
<script>
import stationManageEdit from './form'
import stationManageDetail from './detail'
export default {
    components: {
        stationManageEdit,
        stationManageDetail
    },
    props: {},
    data() {
        return {
            search: {
                groud_id: '',
                web_name: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            },
            openEditHadnle: false,
            openDetailHadnle: false,
            titleText: '编辑',
            timer: '',
            dataInfo: '',
            idInfo: ''
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {
            console.log(this.search)
        },
        addHandle() {
            // this.$router.push({name: 'stationManageAdd'})
            this.timer = new Date().getTime() 
            this.titleText = '新增'
            this.openEditHadnle = true
        },
        editHandle(row) {
            console.log(row)
            this.timer = new Date().getTime() 
            this.openEditHadnle = true
            this.dataInfo  = row
            // this.$router.push({name: 'stationManageEdit', params: {id: row.id, row: row}})
        },
        openEditShow(val) {
            this.openEditHadnle = val
        },
        handleMoreOperating(command, row) {
            switch (command) {
                case 'detail':
                    this.detailHandle(row)
                    break
                case 'station':
                    this.stationHandle(row)
                    break
                case 'delete':
                    this.deleteHandle(row)
                    break
            }
        },
        detailHandle(row) {
            // this.$router.push({name: 'stationManageDetail', params: {id: row.id}})

            this.openDetailHadnle = true
            this.idInfo = row.id
        },
        stationHandle(row) {
            this.$confirm(`确认同步站点「${row.web_sysname}」吗？`, '确认信息').then(() => {
                this.$api.post('mock/pages_example/manager/password/reset', {
                    id: row.id
                }).then(() => {
                    this.$message.success({
                        message: '模拟重置成功',
                        center: true
                    })
                })
            }).catch(() => {})
        },
        deleteHandle(row) {
            this.$confirm('确定删除' + row.web_sysname + ', 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.$api.get('api/web')
                .then(res => {
                    console.log(res.data)
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
