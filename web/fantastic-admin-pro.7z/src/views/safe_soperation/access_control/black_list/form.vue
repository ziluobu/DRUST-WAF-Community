<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" class="addform" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="IP" prop="ip">
                            <el-input v-model="form.ip" />
                        </el-form-item>
                        <el-form-item label="原因" prop="reason">
                            <el-input v-model="form.reason" />
                        </el-form-item>
                        <el-form-item label="过期时间" prop="expire_time">
                            <el-date-picker v-model="form.expire_time" type="date" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                ip: '',
                reason: '',
                expire_time: ''
            },
            ruleForm: {
                ip: [
                    { required: true, message: '请输入IP地址', trigger: 'blur' }
                ],
                reason: [
                    { required: true, message: '请输入原因', trigger: 'blur' }
                ],
                expire_time: [
                    { required: true, message: '请选择过期时间', trigger: 'change' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'blackListEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
    },
    methods: {
        initData() {
            this.$api.get('api/ipallow/*')
                .then(res => {
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/safeSoperation/accessControl/blackList')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
