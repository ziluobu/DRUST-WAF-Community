<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="类型" prop="type">
                            <el-input v-model="form.type" />
                        </el-form-item>
                        <el-form-item label="配置名称" prop="name">
                            <el-input v-model="form.name" />
                        </el-form-item>
                        <el-form-item label="关键字" prop="key">
                            <el-input v-model="form.key" />
                        </el-form-item>
                        <el-form-item label="值" prop="value">
                            <el-input v-model="form.value" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                name: '',
                type: '',
                key: '',
                value: ''
            },
            ruleForm: {
                name: [
                    { required: true, message: '请输入配置名称', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ],
                type: [
                    { required: true, message: '请输入类型', trigger: 'change' }
                ],
                key: [
                    { required: true, message: '请输入关键字', trigger: 'change' }
                ],
                value: [
                    { required: true, message: '请输入值', trigger: 'change' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'configModuleEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
    },
    methods: {
        initData() {
            this.$api.get('api/config/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/systemManage/configModuleList')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
