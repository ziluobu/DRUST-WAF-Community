<template>
    <div>
        <page-main>
            <el-button type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
            <search-bar>
                <el-form :model="search" size="small" label-width="100px">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="网站">
                                <el-input v-model="search.web_id" placeholder="请输入网站" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="web_id" label="网站">
                    <template slot-scope="scope">
                        <el-popover trigger="hover" placement="top">
                            <p>网站: {{ scope.row.web_id }}</p>
                            <p>规则内容: {{ scope.row.rule_content }}</p>
                            <div slot="reference" class="name-wrapper">
                                <el-tag size="medium">{{ scope.row.web_id }}</el-tag>
                            </div>
                        </el-popover>
                    </template>
                </el-table-column>
                <el-table-column prop="remove_sysrule_id" label="移除系统规则" />
                <el-table-column prop="request_uri" label="响应路径" />
                <el-table-column prop="request_method" label="响应方法" />
                <el-table-column prop="status" label="状态">
                    <template slot-scope="scope">
                        {{ scope.row.status == 0?'禁用':'开启' }}
                    </template>
                </el-table-column>
                <el-table-column prop="admin_id" label="管理员id" />
                <el-table-column prop="created_at" label="创建时间" width="160" />
                <el-table-column prop="updated_at" label="更新时间" width="160" />
                <el-table-column prop="describe" label="描述" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="primary" size="mini" plain @click="editHandle(scope.row)">编辑</el-button>
                        <!-- <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button> -->
                        <el-dropdown @command="handleMoreOperating($event, scope.row)">
                            <el-button size="mini">
                                更多操作<i class="el-icon-arrow-down el-icon--right" />
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item command="detail">详情</el-dropdown-item>
                                <el-dropdown-item command="sync">同步策略</el-dropdown-item>
                                <el-dropdown-item command="delete" divided>删除</el-dropdown-item>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
        </page-main>
    </div>
</template>
<script>

export default {
    props: {},
    data() {
        return {
            search: {
                web_id: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            }
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {
            console.log(this.search)
        },
        addHandle() {
            this.$router.push({name: 'strateGoAdd'})
        },
        editHandle(row) {
            console.log(row)
            this.$router.push({name: 'strateGoEdit', params: {id: row.id, row: row}})
        },
        handleMoreOperating(command, row) {
            switch (command) {
                case 'detail':
                    this.detailHandle(row)
                    break
                case 'sync':
                    this.syncHandle(row)
                    break
                case 'delete':
                    this.deleteHandle(row)
                    break
            }
        },
        detailHandle(row) {
            this.$router.push({name: 'strateGoDetail', params: {id: row.id}})
        },
        syncHandle(row) {
            this.$confirm(`确认将「${row.web_id}」执行同步策略 吗？`, '确认信息').then(() => {
                
            }).catch(() => {})
        },
        deleteHandle(row) {
            this.$confirm('确定删除' + row.web_id + ', 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.$api.get('api/whiteRules')
                .then(res => {
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
