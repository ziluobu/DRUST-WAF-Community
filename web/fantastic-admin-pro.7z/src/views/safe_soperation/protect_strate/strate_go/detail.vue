<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" class="addform" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="网站" prop="web_id">
                            <el-input v-model="form.web_id" />
                        </el-form-item>
                        <el-form-item label="响应路径" prop="request_uri">
                            <el-input v-model="form.request_uri" />
                        </el-form-item>
                        <el-form-item label="响应方法" prop="request_method">
                            <el-select v-model="form.request_method" placeholder="请选择" multiple clearable collapse-tags>
                                <el-option label="GET" value="GET" />
                                <el-option label="POST" value="POST" />
                                <el-option label="OPTIONS" value="OPTIONS" />
                                <el-option label="HEAD" value="HEAD" />
                                <el-option label="PUT" value="PUT" />
                                <el-option label="DELETE" value="DELETE" />
                                <el-option label="TRACE" value="TRACE" />
                                <el-option label="CONNECT" value="CONNECT" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="移除系统规则" prop="remove_sysrule_id">
                            <el-input v-model="form.remove_sysrule_id" />
                        </el-form-item>
                        <el-form-item label="状态" prop="status">
                            <el-switch v-model="form.status" />
                            <!-- <el-radio-group v-model="form.status">
                                <el-radio-button label="0">禁用</el-radio-button>
                                <el-radio-button label="1">阻断</el-radio-button>
                                <el-radio-button label="2">告警</el-radio-button>
                            </el-radio-group> -->
                        </el-form-item>
                        <el-form-item label="描述" prop="describe">
                            <el-input v-model="form.describe" type="textarea" />
                        </el-form-item>
                        <el-form-item label="规则内容" prop="rule_content">
                            <el-input v-model="form.rule_content" type="textarea" />
                        </el-form-item>
                        <el-form-item label="管理员ID" prop="admin_id">
                            <el-input v-model="form.admin_id" />
                        </el-form-item>
                        <el-form-item label="创建时间" prop="created_at">
                            <el-input v-model="form.created_at" />
                        </el-form-item>
                        <el-form-item label="更新时间" prop="updated_at">
                            <el-input v-model="form.updated_at" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                web_id: '',
                request_uri: '',
                request_method: ['GET'],
                describe: '',
                remove_sysrule_id: '',
                status: true,
                admin_id: '',
                rule_content: '',
                created_at: '',
                updated_at: ''
            },
            ruleForm: {
                web_id: [
                    { required: true, message: '请输入网站', trigger: 'blur' }
                ],
                param_site: [
                    { required: true, message: '请输入参数', trigger: 'blur' }
                ],
                describe: [
                    { required: true, message: '请输入描述', trigger: 'blur' }
                ],
                remove_sysrule_id: [
                    { required: true, message: '请输入移除规则', trigger: 'blur' }
                ],
                type_id: [
                    { required: true, message: '请输入响应路径', trigger: 'blur' }
                ],
                request_uri: [
                    { required: true, message: '请选择状态', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('api/whiteRules/*')
                .then(res => {
                    this.form = res.data
                })
        }
    }
}
</script>
