<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" class="addform" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="网站" prop="web_id">
                            <el-input v-model="form.web_id" />
                        </el-form-item>
                        <el-form-item label="响应路径" prop="request_uri">
                            <el-input v-model="form.request_uri" />
                        </el-form-item>
                        <el-form-item label="响应方法" prop="request_method">
                            <el-select v-model="form.request_method" placeholder="请选择" multiple clearable collapse-tags>
                                <el-option label="GET" value="GET" />
                                <el-option label="POST" value="POST" />
                                <el-option label="OPTIONS" value="OPTIONS" />
                                <el-option label="HEAD" value="HEAD" />
                                <el-option label="PUT" value="PUT" />
                                <el-option label="DELETE" value="DELETE" />
                                <el-option label="TRACE" value="TRACE" />
                                <el-option label="CONNECT" value="CONNECT" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="移除系统规则" prop="remove_sysrule_id">
                            <el-input v-model="form.remove_sysrule_id" />
                        </el-form-item>
                        <el-form-item label="状态" prop="status">
                            <el-switch v-model="form.status" />
                            <!-- <el-radio-group v-model="form.status">
                                <el-radio-button label="0">禁用</el-radio-button>
                                <el-radio-button label="1">阻断</el-radio-button>
                                <el-radio-button label="2">告警</el-radio-button>
                            </el-radio-group> -->
                        </el-form-item>
                        <el-form-item label="描述" prop="describe">
                            <el-input v-model="form.describe" type="textarea" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                web_id: '',
                request_uri: '',
                request_method: ['GET'],
                describe: '',
                remove_sysrule_id: '',
                status: true
            },
            ruleForm: {
                web_id: [
                    { required: true, message: '请输入网站', trigger: 'blur' }
                ],
                param_site: [
                    { required: true, message: '请输入参数', trigger: 'blur' }
                ],
                describe: [
                    { required: true, message: '请输入描述', trigger: 'blur' }
                ],
                remove_sysrule_id: [
                    { required: true, message: '请输入移除规则', trigger: 'blur' }
                ],
                type_id: [
                    { required: true, message: '请输入响应路径', trigger: 'blur' }
                ],
                request_uri: [
                    { required: true, message: '请选择状态', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'strateGoEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
    },
    methods: {
        initData() {
            this.$api.get('api/whiteRules/*')
                .then(res => {
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/safeSoperation/protectStrate/strateGo')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
