<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="名称" prop="name">
                            <el-input v-model="form.name" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                name: ''
            },
            ruleForm: {
                name: [
                    { required: true, message: '请输入名称', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'policyClassifyEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
    },
    methods: {
        initData() {
            this.$api.get('api/ipallow/*')
                .then(res => {
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/safeSoperation/protectStrate/policyClassify')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
