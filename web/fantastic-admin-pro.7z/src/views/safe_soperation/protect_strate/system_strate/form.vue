<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="是否加黑" prop="is_black">
                            <el-switch v-model="form.is_black" />
                        </el-form-item>
                        <el-form-item label="加黑类型" prop="black_type">
                            <el-input v-model="form.black_type" />
                        </el-form-item>
                        <el-form-item label="加黑个数" prop="black_num">
                            <el-input v-model="form.black_num" />
                        </el-form-item>
                        <el-form-item label="类型" prop="type_id">
                            <el-input v-model="form.type_id" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                is_black: false,
                black_type: '',
                black_num: '',
                type_id: ''
            },
            ruleForm: {
                // is_black: [
                //     { required: true, message: '请选择是否加黑', trigger: 'change' }
                // ],
                black_type: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ],
                black_num: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ],
                type_id: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ]
                // status: [
                //     { required: true, message: '请选择状态', trigger: 'change' }
                // ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'systemStrateEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
    },
    methods: {
        initData() {
            this.$api.get('pi/sysRules/*')
                .then(res => {
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/safeSoperation/protectStrate/systemStrate')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
