<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="规则内容" prop="rule_content">
                            <el-input v-model="form.rule_content" type="textarea" />
                        </el-form-item>
                        <el-form-item label="是否加黑" prop="is_black">
                            <el-switch v-model="form.is_black" />
                        </el-form-item>
                        <el-form-item label="加黑类型" prop="black_type">
                            <el-input v-model="form.black_type" />
                        </el-form-item>
                        <el-form-item label="加黑个数" prop="black_num">
                            <el-input v-model="form.black_num" />
                        </el-form-item>
                        <el-form-item label="类型" prop="type_id">
                            <el-input v-model="form.type_id" />
                        </el-form-item>
                        <el-form-item label="黑名单加入规则" prop="black_append_rule">
                            <el-input v-model="form.black_append_rule" type="textarea" />
                        </el-form-item>
                        <el-form-item label="创建时间" prop="created_at">
                            <el-input v-model="form.created_at" />
                        </el-form-item>
                        <el-form-item label="更新时间" prop="updated_at">
                            <el-input v-model="form.updated_at" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                rule_content: '',
                is_black: false,
                black_type: '',
                black_num: '',
                type_id: '',
                created_at: '',
                updated_at: '',
                black_append_rule: ''
            },
            ruleForm: {
                // is_black: [
                //     { required: true, message: '请选择是否加黑', trigger: 'change' }
                // ],
                black_type: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ],
                black_num: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ],
                type_id: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ]
                // status: [
                //     { required: true, message: '请选择状态', trigger: 'change' }
                // ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('pi/sysRules/*')
                .then(res => {
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/safeSoperation/protectStrate/systemStrate')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
