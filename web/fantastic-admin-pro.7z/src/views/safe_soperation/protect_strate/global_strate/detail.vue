<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" class="addform" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="网站" prop="web_id">
                            <el-input v-model="form.web_id" />
                        </el-form-item>
                        <el-form-item label="响应路径" prop="request_uri">
                            <el-input v-model="form.request_uri" />
                        </el-form-item>
                        <el-form-item label="响应方法" prop="request_method">
                            <el-select v-model="form.request_method" placeholder="请选择" multiple clearable collapse-tags>
                                <el-option label="GET" value="GET" />
                                <el-option label="POST" value="POST" />
                                <el-option label="OPTIONS" value="OPTIONS" />
                                <el-option label="HEAD" value="HEAD" />
                                <el-option label="PUT" value="PUT" />
                                <el-option label="DELETE" value="DELETE" />
                                <el-option label="TRACE" value="TRACE" />
                                <el-option label="CONNECT" value="CONNECT" />
                            </el-select>
                        </el-form-item>
                        <el-form-item label="参数" prop="param_site">
                            <el-select v-model="form.param_site" placeholder="请选择" clearable>
                                <el-option label="无" value="0" />
                                <el-option label="请求行" value="1" />
                                <el-option label="请求体" value="2" />
                                <el-option label="header" value="3" />
                            </el-select>
                        </el-form-item>
                        <div v-if="form.param_site">
                            <div>参数内容：</div>
                            <el-form-item label="key" prop="key">
                                <el-input v-model="form.key" />
                            </el-form-item>
                            <el-form-item label="value" prop="value">
                                <el-input v-model="form.value" />
                            </el-form-item>
                            <el-form-item label="operator" prop="operator">
                                <el-select v-model="form.operator">
                                    <el-option label="包含" value="@contains" />
                                    <el-option label="不包含" value="!@contains" />
                                    <el-option label="包含(词)" value="containsWord" />
                                    <el-option label="包含(词)" value="!containsWord" />
                                    <el-option label="等于" value="@eq" />
                                    <el-option label="不等于" value="!@eq" />
                                    <el-option label="正则" value="@rx" />
                                </el-select>
                            </el-form-item>
                        </div>
                        <el-form-item label="描述" prop="describe">
                            <el-input v-model="form.describe" />
                        </el-form-item>
                        <el-form-item label="是否加黑" prop="is_black">
                            <el-switch v-model="form.is_black" />
                        </el-form-item>
                        <el-form-item label="加黑类型" prop="black_type">
                            <el-radio-group v-model="form.black_type">
                                <el-radio-button label="0">永久</el-radio-button>
                                <el-radio-button label="1">小时</el-radio-button>
                                <el-radio-button label="2">天</el-radio-button>
                            </el-radio-group>
                        </el-form-item>
                        <el-form-item label="加黑个数" prop="black_num">
                            <el-input v-model="form.black_num" />
                        </el-form-item>
                        <el-form-item label="类型" prop="type_id">
                            <el-input v-model="form.type_id" />
                        </el-form-item>
                        <el-form-item label="状态" prop="status">
                            <el-radio-group v-model="form.status">
                                <el-radio-button label="0">禁用</el-radio-button>
                                <el-radio-button label="1">阻断</el-radio-button>
                                <el-radio-button label="2">告警</el-radio-button>
                            </el-radio-group>
                        </el-form-item>
                        <el-form-item label="管理员ID" prop="admin_id">
                            <el-input v-model="form.admin_id" />
                        </el-form-item>
                        <el-form-item label="规则内容" prop="rule_content">
                            <el-input v-model="form.rule_content" type="textarea" />
                        </el-form-item>
                        <el-form-item label="创建时间" prop="created_at">
                            <el-input v-model="form.created_at" />
                        </el-form-item>
                        <el-form-item label="更新时间" prop="updated_at">
                            <el-input v-model="form.updated_at" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                web_id: '',
                request_uri: '',
                request_method: [],
                param_site: '0',
                describe: '',
                is_black: false,
                black_type: 0,
                black_num: '',
                type_id: '',
                status: 0,
                operator: '@contains',
                key: '',
                value: '',
                admin_id: '',
                rule_content: '',
                created_at: '',
                updated_at: ''
            },
            ruleForm: {
                web_id: [
                    { required: true, message: '请输入网站', trigger: 'blur' }
                ],
                param_site: [
                    { required: true, message: '请输入参数', trigger: 'blur' }
                ],
                describe: [
                    { required: true, message: '请输入描述', trigger: 'blur' }
                ],
                operator: [
                    { required: true, message: '请选择operator', trigger: 'change' }
                ],
                type_id: [
                    { required: true, message: '请输入类型', trigger: 'blur' }
                ]
                // status: [
                //     { required: true, message: '请选择状态', trigger: 'change' }
                // ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('api/globalRules/*')
                .then(res => {
                    this.form = res.data
                })
        }
    }
}
</script>
