<template>
    <div>
        <page-main>
            <el-button type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
            <search-bar>
                <el-form :model="search" size="small" label-width="100px">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="网站">
                                <el-input v-model="search.web_id" placeholder="请输入网站" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="类型">
                                <el-input v-model="search.type_id" placeholder="请输入类型" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="状态">
                                <el-select v-model="search.status">
                                    <el-option label="全部" value="" />
                                    <el-option value="0" label="禁用" />
                                    <el-option value="1" label="阻断" />
                                    <el-option value="2" label="告警" />
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <batch-action-bar v-if="batch.enable" :data="dataList" :selection-data="batch.selectionDataList" @check-all="$refs.table.toggleAllSelection()" @check-null="$refs.table.clearSelection()">
                <el-button size="small" @click="multiOnchangeHandle($event)">批量操作</el-button>
            </batch-action-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row @selection-change="batch.selectionDataList = $event">
                <el-table-column v-if="batch.enable" type="selection" width="40" />
                <el-table-column prop="web_id" label="网站" />
                <el-table-column prop="request_uri" label="响应路径" />
                <el-table-column prop="request_method" label="响应方法" />
                <el-table-column prop="param_site" label="参数">
                    <template slot-scope="scope">
                        <el-popover trigger="hover" placement="top">
                            <div v-for="(item, index) in scope.row.param_content" :key="index">
                                <p>key: {{ item.key }}</p>
                                <p>value: {{ item.value }}</p>
                                <p>operator: {{ $common.replaceStr(item.operator) }}</p>
                            </div>
                            <div slot="reference" class="name-wrapper">
                                <el-tag size="medium">{{ scope.row.param_site }}</el-tag>
                            </div>
                        </el-popover>
                    </template>
                </el-table-column>
                <el-table-column prop="describe" label="描述" />
                <el-table-column prop="is_black" label="黑名单">
                    <template slot-scope="scope">
                        {{ scope.row.is_black == 0?'不加黑':'加黑' }}
                    </template>
                </el-table-column>
                <el-table-column prop="black_type" label="黑名单类型">
                    <template slot-scope="scope">
                        {{ scope.row.black_type == 0?'永久': scope.row.black_type == 1?'小时':'天' }}
                    </template>
                </el-table-column>
                <el-table-column prop="black_num" label="黑名单数量" />
                <el-table-column prop="black_time" label="黑名单时间" />
                <el-table-column prop="type_id" label="类型" />
                <el-table-column prop="rule_content" label="规则内容" />
                <el-table-column prop="status" label="状态">
                    <template slot-scope="scope">
                        {{ scope.row.status == 0?'禁用': scope.row.status == 1?'阻断':'告警' }}
                        <!-- <el-switch v-model="scope.row.status" @change="onChangeStatus($event, scope.row)" /> -->
                    </template>
                </el-table-column>
                <el-table-column prop="admin_id" label="管理员id" />
                <el-table-column prop="created_at" label="创建时间" width="160" />
                <el-table-column prop="updated_at" label="更新时间" width="160" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="primary" size="mini" plain @click="editHandle(scope.row)">编辑</el-button>
                        <!-- <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button> -->
                        <el-dropdown @command="handleMoreOperating($event, scope.row)">
                            <el-button size="mini">
                                更多操作<i class="el-icon-arrow-down el-icon--right" />
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item command="detail">详情</el-dropdown-item>
                                <el-dropdown-item command="sync">同步策略</el-dropdown-item>
                                <el-dropdown-item command="delete" divided>删除</el-dropdown-item>
                            </el-dropdown-menu>
                        </el-dropdown>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
        </page-main>
        <el-dialog title="批量操作" :visible.sync="multiStatusVisible" width="30%">
            <el-form :model="multiStatusForm">
                <el-form-item label="状态">
                    <el-select v-model="multiStatusForm.status">
                        <el-option value="0" label="禁用" />
                        <el-option value="1" label="阻断" />
                        <el-option value="2" label="告警" />
                    </el-select>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="multiStatusVisible = false">取 消</el-button>
                <el-button type="primary" @click="multiStatusVisible = false">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>

export default {
    props: {},
    data() {
        return {
            search: {
                web_id: '',
                type_id: '',
                status: ''
            },
            // 批量操作
            batch: {
                enable: true,
                selectionDataList: []
            },
            multiStatusVisible: false,
            multiStatusForm: {
                status: '0'
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            }
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {
            console.log(this.search)
        },
        
        multiOnchangeHandle() {
            console.log(this.batch.selectionDataList)
            this.multiStatusVisible = true
        },
        onChangeStatus(val, row) {
            this.$confirm(`确认${val ? '启用' : '停用'}「${row.web_id}」吗？`, '确认信息').then(() => {
                // this.$api.post('mock/pages_example/manager/change/status', {
                //     id: row.id,
                //     status: val
                // }).then(() => {
                //     this.$message.success({
                //         message: `模拟${val ? '启用' : '停用'}成功`,
                //         center: true
                //     })
                // })
            }).catch(() => {
                row.status = !val
            })
        },
        addHandle() {
            this.$router.push({name: 'webProtectAdd'})
        },
        editHandle(row) {
            console.log(row)
            this.$router.push({name: 'webProtectEdit', params: {id: row.id, row: row}})
        },
        handleMoreOperating(command, row) {
            switch (command) {
                case 'detail':
                    this.detailHandle(row)
                    break
                case 'sync':
                    this.syncHandle(row)
                    break
                case 'delete':
                    this.deleteHandle(row)
                    break
            }
        },
        detailHandle(row) {
            this.$router.push({name: 'webProtectDetail', params: {id: row.id}})
        },
        syncHandle(row) {
            this.$confirm(`确认将「${row.web_id}」执行同步策略 吗？`, '确认信息').then(() => {
                
            }).catch(() => {})
        },
        deleteHandle(row) {
            this.$confirm('确定删除' + row.web_id + ', 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.$api.get('api/webRules')
                .then(res => {
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
