<template>
    <div>
        <page-main>
            <router-link :to="{name: 'breadcrumbExampleDetail1'}">查看详情页</router-link>
        </page-main>
    </div>
</template>
