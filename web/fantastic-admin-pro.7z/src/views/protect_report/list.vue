<template>
    <div>
        <page-main>
            防护报告开发中。。。
        </page-main>
    </div>
</template>