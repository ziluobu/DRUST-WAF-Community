<template>
    <div>
        <page-main>
            <el-button type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
            <search-bar>
                <el-form :model="search" size="small" label-width="100px">
                    <el-row>
                        <el-col :span="12">
                            <el-form-item label="单位名称">
                                <el-input v-model="search.group_name" placeholder="请输入单位名称" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="group_name" label="单位名称" />
                <el-table-column prop="created_at" label="创建时间" />
                <el-table-column prop="updated_at" label="更新时间" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="primary" size="mini" plain @click="editHandle(scope.row)">编辑</el-button>
                        <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
            <el-dialog v-if="openEditHadnle" :key="timer" :title="titleText" :visible.sync="openEditHadnle" width="70%">
                <stationManageEdit :data-info="dataInfo" @openEditShow="openEditShow" @formList="initData" />
            </el-dialog>
        </page-main>
    </div>
</template>
<script>
import stationManageEdit from './form'
export default {
    components: {
        stationManageEdit
    },
    props: {},
    data() {
        return {
            search: {
                group_name: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            },
            openEditHadnle: false,
            openDetailHadnle: false,
            titleText: '编辑',
            timer: '',
            dataInfo: '',
            idInfo: ''
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {
            console.log(this.search)
        },
        addHandle() {
            // this.$router.push({name: 'unitManageAdd'})
            this.timer = new Date().getTime() 
            this.openEditHadnle = true
        },
        editHandle(row) {
            console.log(row)
            this.timer = new Date().getTime() 
            this.openEditHadnle = true
            this.dataInfo  = row
            // this.$router.push({name: 'unitManageEdit', params: {id: row.id, row: row}})
        },
        openEditShow(val) {
            this.openEditHadnle = val
        },
        deleteHandle(row) {
            this.$confirm('确定删除' + row.name + ', 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.$api.get('api/group')
                .then(res => {
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
