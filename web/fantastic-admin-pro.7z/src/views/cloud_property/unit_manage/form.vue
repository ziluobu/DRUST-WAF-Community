<template>
    <div>
        <!-- <page-main> -->
        <el-row>
            <el-col :md="24" :lg="12">
                <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                    <el-form-item label="单位名称" prop="group_name">
                        <el-input v-model="form.group_name" />
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <!-- </page-main> -->
        <!-- <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar> -->
        <div class="btn-box">
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </div>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    props: {
        dataInfo: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            id: '',
            form: {
                group_name: ''
            },
            ruleForm: {
                group_name: [
                    { required: true, message: '请输入单位名称', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        // if (this.$route.name == 'unitManageEdit') {
        //     this.id = this.$route.params.id
        //     this.initData()
        // }
        if (this.dataInfo) {
            this.id = this.dataInfo.id
            this.initData()
        }
        console.log(this.dataInfo, 'this.dataInfo')
    },
    methods: {
        initData() {
            this.$api.get('api/group/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    // this.$router.push('/cloudProperty/unitManageList')
                    this.$emit('formList')
                    this.$emit('openEditShow', false)
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
            this.$emit('openEditShow', false)
        }
    }
}
</script>
