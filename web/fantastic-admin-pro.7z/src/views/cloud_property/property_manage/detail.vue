<template>
    <div>
        <!-- <page-main> -->
        <el-row>
            <el-col :md="24" :lg="12">
                <el-form ref="form" class="addform" :rules="ruleForm" :model="form" label-width="120px">
                    <el-form-item label="单位名称" prop="group_id">
                        <el-input v-model="form.group_id" />
                    </el-form-item>
                    <el-form-item label="ip" prop="ip">
                        <el-input v-model="form.ip" />
                    </el-form-item>
                    <el-form-item label="联系人" prop="contact">
                        <el-input v-model="form.contact" />
                    </el-form-item>
                    <el-form-item label="联系方式" prop="phone">
                        <el-input v-model="form.phone" />
                    </el-form-item>
                    <el-form-item label="创建时间" prop="created_at">
                        <el-input v-model="form.created_at" />
                    </el-form-item>
                    <el-form-item label="更新时间" prop="updated_at">
                        <el-input v-model="form.updated_at" />
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <!-- </page-main> -->
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                group_id: '',
                ip: '',
                concat: '',
                phone: '',
                created_at: '',
                updated_at: ''
            },
            ruleForm: {
                concat: [
                    { required: true, message: '请输入联系人', trigger: 'blur' },
                    { min: 3, message: '长度最少三个字符', trigger: 'blur' }
                ],
                group_id: [
                    { required: true, message: '请输入类型', trigger: 'change' }
                ],
                phone: [
                    { required: true, message: '请输入手机号', trigger: 'blur' },
                    { pattern: /^((0\d{2,3}-\d{7,8})|(1[3456789]\d{9}))$/, message: '请输入合法手机号/电话号', trigger: 'blur' }
                ],
                ip: [
                    { required: true, message: '请输入IP', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('api/assets/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        }
    }
}
</script>
