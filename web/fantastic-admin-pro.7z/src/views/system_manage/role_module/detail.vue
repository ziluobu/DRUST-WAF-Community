<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="角色名称" prop="name">
                            <el-input v-model="form.name" />
                        </el-form-item>
                        <el-form-item label="列表排序" prop="listsort">
                            <el-input v-model="form.listsort" />
                        </el-form-item>
                        <el-form-item label="菜单" prop="menuIds">
                            <el-input v-model="form.menuIds" @focus="setVisible = true" />
                        </el-form-item>
                        <el-form-item label="创建时间" prop="created_at">
                            <el-input v-model="form.created_at" />
                        </el-form-item>
                        <el-form-item label="更新时间" prop="updated_at">
                            <el-input v-model="form.updated_at" />
                        </el-form-item>
                        <el-form-item label="备注" prop="note">
                            <el-input v-model="form.note" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                name: '',
                listsort: '',
                note: '',
                menuIds: '系统管理',
                created_at: '',
                updated_at: ''
            },
            ruleForm: {
                name: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('api/role/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        }
    }
}
</script>
