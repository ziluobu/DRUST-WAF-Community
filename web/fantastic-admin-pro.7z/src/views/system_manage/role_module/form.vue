<template>
    <div>
        <page-main>
            <el-row>
                <el-col :md="24" :lg="12">
                    <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                        <el-form-item label="角色名称" prop="name">
                            <el-input v-model="form.name" />
                        </el-form-item>
                        <el-form-item label="列表排序" prop="listsort">
                            <el-input v-model="form.listsort" />
                        </el-form-item>
                        <el-form-item label="菜单" prop="menuIds">
                            <el-input v-model="form.menuIds" @focus="setVisible = true" />
                        </el-form-item>
                    </el-form>
                </el-col>
            </el-row>
        </page-main>
        <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar>
        <el-dialog title="权限设置" :visible.sync="setVisible" width="50%">
            <el-row v-loading="setLoading">
                <el-tree ref="tree"
                         style="height: 500px; overflow: auto;"
                         :data="treeData"
                         show-checkbox
                         node-key="id"
                         default-expand-all
                         :default-checked-keys="checkedKeys"
                         :props="defaultProps"
                />
            </el-row>
            <div slot="footer" class="dialog-footer">
                <el-button @click="setVisible = false">取 消</el-button>
                <el-button type="primary" @click="addSetSubmit">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                name: '',
                listsort: '',
                menuIds: ''
            },
            ruleForm: {
                name: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ]
            }, 
            treeData: [],
            checkedKeys: [],
            defaultProps: {
                children: 'children',
                label: 'name'
            },
            checkedNames: [],
            setLoading: false,
            setVisible: false
        }
    },
    mounted() {
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        if (this.$route.name == 'roleModuleEdit') {
            this.id = this.$route.params.id
            this.initData()
        }
        this.initRoles()
    },
    methods: {
        initRoles() {
            const _this = this
            const roleLists = this.$store.state.menu.routes[0].children
            roleLists.forEach(item => {
                console.log(item)
                var obj1 = {
                    id: item.path,
                    name: item.meta.title,
                    children: []
                }
                if (item.children && item.children.length > 0) {
                    item.children.forEach(Ite => {
                        var obj2 = {
                            id: Ite.path,
                            name: Ite.meta.title
                        }
                        obj1.children.push(obj2)
                    })
                }
                _this.treeData.push(obj1)
                console.log(_this.treeData)
            })
        },
        initData() {
            this.$api.get('api/role/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        },
        addSetSubmit() {
            const _self = this
            // var ids = this.$refs.tree.getHalfCheckedKeys().concat(this.$refs.tree.getCheckedKeys())
            const checkedNodes = this.$refs.tree.getCheckedNodes()
            checkedNodes.forEach(item => {
                console.log(item)
                _self.checkedNames.push(item.name)
            })
            _self.form.menuIds = _self.checkedNames.toString()
            this.setVisible = false
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/systemManage/configModuleList')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
