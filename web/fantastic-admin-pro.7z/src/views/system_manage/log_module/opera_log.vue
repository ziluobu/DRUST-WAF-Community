<template>
    <div>
        <page-main>
            <search-bar>
                <el-form :model="search" size="small" label-width="80px">
                    <el-row>
                        <el-col :md="8">
                            <el-form-item label="用户名">
                                <el-input v-model="search.username" placeholder="请输入用户名" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :md="8">
                            <el-form-item label="模块名称">
                                <el-input v-model="search.module" placeholder="请输入模块名称" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="响应方法" prop="request_method">
                                <el-select v-model="search.request_method" placeholder="请选择" clearable>
                                    <el-option label="GET" value="GET" />
                                    <el-option label="POST" value="POST" />
                                    <el-option label="OPTIONS" value="OPTIONS" />
                                    <el-option label="HEAD" value="HEAD" />
                                    <el-option label="PUT" value="PUT" />
                                    <el-option label="DELETE" value="DELETE" />
                                    <el-option label="TRACE" value="TRACE" />
                                    <el-option label="CONNECT" value="CONNECT" />
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="API状态" prop="api_status">
                                <el-select v-model="search.api_status" placeholder="请选择" clearable>
                                    <el-option label="无" value="" />
                                    <el-option label="2000" value="2000" />
                                    <el-option label="3000" value="3000" />
                                    <el-option label="3001" value="3001" />
                                    <el-option label="4002" value="4002" />
                                    <el-option label="4003" value="4003" />
                                    <el-option label="4004" value="4004" />
                                    <el-option label="4100" value="4100" />
                                    <el-option label="4101" value="4101" />
                                    <el-option label="4102" value="4102" />
                                    <el-option label="4300" value="4300" />
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :md="12">
                            <el-form-item label="日期范围">
                                <el-date-picker v-model="search.beginTime" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="module" label="模块名称" />
                <el-table-column prop="request_method" label="请求方法" />
                <el-table-column prop="admin_id" label="管理员ID" />
                <el-table-column prop="username" label="用户名" />
                <el-table-column prop="oper_url" label="操作路径" />
                <el-table-column prop="oper_ip" label="操作IP" />
                <el-table-column prop="oper_location" label="操作地址" />
                <el-table-column prop="status" label="状态" />
                <el-table-column prop="api_status" label="API状态" />
                <el-table-column prop="created_at" label="创建时间" width="160" />
                <el-table-column prop="updated_at" label="更新时间" width="160" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button>
                        <el-button type="warning" size="mini" plain @click="clearHandle(scope.row)">清空</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
        </page-main>
    </div>
</template>
<script>

export default {
    props: {},
    data() {
        return {
            search: {
                module: '',
                username: '',
                request_method: '',
                api_status: '',
                beginTime: '',
                endTime: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            }
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {},
        deleteHandle(row) {
            this.$confirm('确定删除' + row.module + ', 是否继续?', '确认信息', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {})
        },
        clearHandle(row) {
            this.$confirm('确定清空' + row.module + ', 是否继续?', '确认信息', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.$api.get('api/opertlog')
                .then(res => {
                    console.log(res.data)
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
