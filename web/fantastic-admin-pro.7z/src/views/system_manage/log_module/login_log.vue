<template>
    <div>
        <page-main>
            <search-bar>
                <el-form :model="search" size="small" label-width="80px">
                    <el-row>
                        <el-col :md="8">
                            <el-form-item label="登录人">
                                <el-input v-model="search.loginName" placeholder="请输入登录人" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :md="8">
                            <el-form-item label="登录IP">
                                <el-input v-model="search.ipaddr" placeholder="请输入登录IP" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :md="8">
                            <el-form-item label="状态">
                                <el-select v-model="search.status">
                                    <el-option label="全部" value="" />
                                    <el-option label="正常" value="1" />
                                    <el-option label="停用" value="0" />
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :md="12">
                            <el-form-item label="日期范围">
                                <el-date-picker v-model="search.beginTime" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="login_name" label="登录人" />
                <el-table-column prop="ipaddr" label="登录IP" />
                <el-table-column prop="login_location" label="登录地址" />
                <el-table-column prop="browser" label="浏览器" />
                <el-table-column prop="os" label="操作系统" />
                <el-table-column prop="net" label="网络" />
                <el-table-column prop="status" label="状态">
                    <template slot-scope="scope">
                        {{ scope.row.status==1?'正常':'停用' }}
                    </template>
                </el-table-column>
                <el-table-column prop="msg" label="消息" />
                <el-table-column prop="created_at" label="创建时间" />
                <el-table-column prop="updated_at" label="更新时间" />
                <el-table-column label="操作" width="200" fixed="right">
                    <template slot-scope="scope">
                        <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button>
                        <el-button type="warning" size="mini" plain @click="clearHandle(scope.row)">清空</el-button>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
        </page-main>
    </div>
</template>
<script>

export default {
    props: {},
    data() {
        return {
            search: {
                loginName: '',
                ipaddr: '',
                status: '',
                beginTime: '',
                endTime: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            }
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {},
        deleteHandle(row) {
            this.$confirm('确定删除' + row.login_name + ', 是否继续?', '确认信息', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        clearHandle(row) {
            this.$confirm('确定清空' + row.login_name + ', 是否继续?', '确认信息', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {})
        },
        initData() {
            this.$api.get('api/loginlog')
                .then(res => {
                    console.log(res.data)
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
