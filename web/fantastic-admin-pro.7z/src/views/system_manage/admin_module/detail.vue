<template>
    <div>
        <!-- <page-main> -->
        <el-row>
            <el-col :md="24" :lg="12">
                <el-form ref="form" :rules="ruleForm" :model="form" label-width="130px">
                    <el-form-item label="用户名" prop="username">
                        <el-input v-model="form.username" />
                    </el-form-item>
                    <el-form-item label="真实姓名" prop="realname">
                        <el-input v-model="form.realname" />
                    </el-form-item>
                    <el-form-item label="启用 / 冻结">
                        <el-switch v-model="form.status" />
                    </el-form-item>
                    <el-form-item label="角色">
                        <el-select v-model="form.roleId" placeholder="请选择角色">
                            <el-option label="超级管理员" value="1" />
                            <el-option label="普通用户" value="2" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="最后一次登录时间" prop="last_time">
                        <el-input v-model="form.last_time" />
                    </el-form-item>
                    <el-form-item label="最后一次登录IP" prop="last_ip">
                        <el-input v-model="form.last_ip" />
                    </el-form-item>
                        
                    <el-form-item label="备注" prop="note">
                        <el-input v-model="form.note" type="textarea" />
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <!-- </page-main> -->
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    data() {
        return {
            id: '',
            form: {
                username: '',
                password: '',
                realname: '',
                status: 0,
                note: '',
                roleId: '',
                last_time: '',
                last_ip: '',
                created_at: '',
                updated_at: ''
            },
            ruleForm: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入类型', trigger: 'change' }
                ],
                realname: [
                    { required: true, message: '请输入关键字', trigger: 'change' }
                ]
            }
        }
    },
    mounted() {
        this.id = this.$route.params.id
        this.initData()
    },
    methods: {
        initData() {
            this.$api.get('api/manage/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    this.$router.push('/systemManage/configModuleList')
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
        }
    }
}
</script>
