<template>
    <div>
        <!-- <page-main> -->
        <el-row>
            <el-col :md="24" :lg="12">
                <el-form ref="form" :rules="ruleForm" :model="form" label-width="120px">
                    <el-form-item label="用户名" prop="username">
                        <el-input v-model="form.username" />
                    </el-form-item>
                    <el-form-item v-if="type=='add'" label="密码" prop="password">
                        <el-input v-model="form.password" />
                    </el-form-item>
                    <el-form-item label="真实姓名" prop="realname">
                        <el-input v-model="form.realname" />
                    </el-form-item>
                    <el-form-item label="启用 / 冻结">
                        <el-switch v-model="form.status" />
                    </el-form-item>
                    <el-form-item label="角色">
                        <el-select v-model="form.roleId" placeholder="请选择角色">
                            <el-option label="超级管理员" value="1" />
                            <el-option label="普通用户" value="2" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="备注" prop="note">
                        <el-input v-model="form.note" type="textarea" />
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <!-- </page-main> -->
        <!-- <fixed-action-bar>
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </fixed-action-bar> -->
        <div class="btn-box">
            <el-button type="primary" @click="submitForm('form')">确定</el-button>
            <el-button type="info" @click="resetForm('form')">取消</el-button>
        </div>
    </div>
</template>
<script>
// import store from '@/store/index'

export default {
    props: {
        dataInfo: {
            type: String,
            default: ''
        }
    },
    data() {
        return {
            id: '',
            type: 'add',
            form: {
                username: '',
                password: '',
                realname: '',
                status: 0,
                note: '',
                roleId: ''
            },
            ruleForm: {
                username: [
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
                ],
                password: [
                    { required: true, message: '请输入类型', trigger: 'change' }
                ],
                realname: [
                    { required: true, message: '请输入关键字', trigger: 'change' }
                ]
            }
        }
    },
    mounted() {
        
        // this.$store.commit('settings/setTitle', '编辑页面')
        // console.log('id:', this.id, this.$store.state.settings.title)
        // this.$route.meta.title = '编辑页面'
        // this.initData()
        // if (this.$route.name == 'adminModuleEdit') {
        //     this.id = this.$route.params.id
        //     this.type = 'edit'
        //     console.log('if', this.type)
        //     this.initData()
        // }
        if (this.dataInfo) {
            this.type = 'edit'
            this.id = this.dataInfo.id
            this.initData()
        }
        
        console.log(this.type)
    },
    methods: {
        initData() {
            this.$api.get('api/manage/*')
                .then(res => {
                    console.log(res)
                    this.form = res.data
                })
        },
        submitForm(formName) {
            this.$refs[formName].validate(valid => {
                if (valid) {
                    this.$message.success('新增成功！')
                    console.log(this.form)
                    // this.$router.push('/systemManage/configModuleList')
                    this.$emit('formList')
                    this.$emit('openEditShow', false)
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        },
        resetForm(formName) {
            this.$refs[formName].resetFields()
            this.$emit('openEditShow', false)
        }
    }
}
</script>

