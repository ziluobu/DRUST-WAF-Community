<template>
    <div>
        <page-main>
            <el-button type="primary" icon="el-icon-plus" @click="addHandle">新增</el-button>
            <search-bar>
                <el-form :model="search" size="small" label-width="100px">
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="用户名">
                                <el-input v-model="search.username" placeholder="请输入用户名" clearable @keydown.enter.native="searchHandle" @clear="searchHandle" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="状态">
                                <el-select v-model="search.status">
                                    <option label="全部" value="" />
                                    <option label="启用" value="1" />
                                    <option label="冻结" value="0" />
                                </el-select>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item label="日期">
                                <el-date-picker v-model="search.beginTime" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期" />
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search" @click="searchHandle">筛 选</el-button>
                    </el-form-item>
                </el-form>
            </search-bar>
            <el-table ref="table" class="list-table" :data="dataList" :loading="loading" border stripe highlight-current-row>
                <el-table-column prop="username" label="用户名" />
                <el-table-column prop="realname" label="真实姓名" />
                <el-table-column prop="last_ip" label="最后一次登录IP" />
                <el-table-column prop="last_time" label="最后一次登录时间" />
                <el-table-column prop="status" label="状态">
                    <template slot-scope="scope">
                        <!-- {{ scope.row.status == 1?'启用':'冻结' }} -->
                        <el-switch v-model="scope.row.status" @change="onChangeStatus($event, scope.row)" />
                    </template>
                </el-table-column>
                <el-table-column prop="created_at" label="创建时间" width="160" />
                <el-table-column prop="updated_at" label="更新时间" width="160" />
                <el-table-column prop="note" label="备注" />
                <el-table-column label="操作" width="200" align="center">
                    <template slot-scope="scope">
                        <el-button type="primary" size="mini" plain @click="editHandle(scope.row)">编辑</el-button>
                        <el-dropdown @command="handleMoreOperating($event, scope.row)">
                            <el-button size="mini">
                                更多操作<i class="el-icon-arrow-down el-icon--right" />
                            </el-button>
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item command="detail">详情</el-dropdown-item>
                                <el-dropdown-item command="resetPassword">重置密码</el-dropdown-item>
                                <el-dropdown-item command="delete" divided>删除</el-dropdown-item>
                            </el-dropdown-menu>
                        </el-dropdown>
                        <!-- <el-button type="danger" size="mini" plain @click="deleteHandle(scope.row)">删除</el-button> -->
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination
                :current-page="page.currentPage"
                :page-sizes="page.pageSizes"
                :page-size="page.pageSize"
                :total="page.total"
                layout="total, sizes, ->, prev, pager, next, jumper"
                :hide-on-single-page="false"
                class="pagination" background @size-change="handleSizeChange" @current-change="handleCurrentChange"
            />
        </page-main>
        <el-dialog v-if="openEditHadnle" :key="timer" :title="titleText" :visible.sync="openEditHadnle" width="70%">
            <stationManageEdit :data-info="dataInfo" @openEditShow="openEditShow" @formList="initData" />
        </el-dialog>
        <el-dialog v-if="openDetailHadnle" :key="timer" :id-info="idInfo" title="详情" :visible.sync="openDetailHadnle" width="70%">
            <stationManageDetail />
        </el-dialog>
    </div>
</template>
<script>
import stationManageEdit from './form'
import stationManageDetail from './detail'
export default {
    components: {
        stationManageEdit,
        stationManageDetail
    },
    props: {},
    data() {
        return {
            search: {
                username: '',
                status: '',
                beginTime: ''
            },
            dataList: [],
            loading: false,
            page: {
                currentPage: 1,
                pageSizes: [10, 50, 100],
                pageSize: 10,
                total: 0
            },
            openEditHadnle: false,
            openDetailHadnle: false,
            titleText: '编辑',
            timer: '',
            dataInfo: '',
            idInfo: ''
        }
    },
    mounted() {
        this.initData()
    },
    methods: {
        searchHandle() {
            console.log(this.search)
        },
        onChangeStatus(val, row) {
            this.$confirm(`确认${val ? '启用' : '停用'}「${row.username}」吗？`, '确认信息').then(() => {
                // this.$api.post('mock/pages_example/manager/change/status', {
                //     id: row.id,
                //     status: val
                // }).then(() => {
                //     this.$message.success({
                //         message: `模拟${val ? '启用' : '停用'}成功`,
                //         center: true
                //     })
                // })
            }).catch(() => {
                row.status = !val
            })
        },
        openEditShow(val) {
            this.openEditHadnle = val
        },
        addHandle() {
            console.log('新增')
            // this.$router.push({name: 'adminModuleAdd'})
            this.timer = new Date().getTime() 
            this.titleText = '新增'
            this.openEditHadnle = true
        },
        editHandle(row) {
            console.log(row)
            // this.$router.push({name: 'adminModuleEdit', params: {id: row.id, row: row}})
            this.timer = new Date().getTime() 
            this.openEditHadnle = true
            this.dataInfo  = row
        },
        handleMoreOperating(command, row) {
            switch (command) {
                case 'detail':
                    this.detailHandle(row)
                    break
                case 'resetPassword':
                    this.resetPassHandle(row)
                    break
                case 'delete':
                    this.deleteHandle(row)
                    break
            }
        },
        detailHandle(row) {
            console.log(row)
            // this.$router.push({name: 'adminModuleDetail', params: {id: row.id}})
            this.openDetailHadnle = true
            this.idInfo = row.id
        },
        resetPassHandle(row) {
            this.$confirm(`确认将「${row.username}」的密码重置为 “123456” 吗？`, '确认信息').then(() => {
                this.$api.post('mock/pages_example/manager/password/reset', {
                    id: row.id
                }).then(() => {
                    this.$message.success({
                        message: '模拟重置成功',
                        center: true
                    })
                })
            }).catch(() => {})
        },
        deleteHandle(row) {
            this.$confirm('确定删除' + row.username + ', 是否继续?', '确认信息', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                this.$message({
                    type: 'success',
                    message: '删除成功!'
                })
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                })          
            })
        },
        initData() {
            this.loading = true
            this.$api.get('api/manage')
                .then(res => {
                    console.log(res.data)
                    this.loading = false
                    this.dataList = res.data.list
                    this.page.total = Number(res.data.count)
                })
        },
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`)
        },
        handleCurrentChange(val) {
            console.log(`当前页: ${val}`)
        }
    }
}
</script>
