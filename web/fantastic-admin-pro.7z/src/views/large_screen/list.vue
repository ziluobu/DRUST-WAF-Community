<template>
    <div>
        <page-main>
            可视化大屏开发中。。。
        </page-main>
    </div>
</template>